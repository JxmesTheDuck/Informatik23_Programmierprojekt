
/**
 * Write a description of class BALL here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class BALL extends KREIS {
    //zusätzliche Attribute
    private int deltaX;
    private int deltaY;
    
     /**
     * Konstruktor von Ball
     * Farbe gelb, Radius 10, deltaX=deltaY=-1, Mittelpunkt (400|300)
     */
    public BALL(){
        super();
        this.deltaX=-1;
        this.deltaY=-1;
        this.setzeFarbe("gelb");
        this.setzeRadius(10);
        this.setzeMittelpunkt(400,300);
    }
    
     /**
     * bewegt den Ball um deltaX in x-Richtung und deltaY in y-Richtung 
     */
    public void bewegen (){
        this.verschiebenUm(deltaX,deltaY);
    }
    
    /**
     * invertiert deltaX
     */
    public void invertiereDeltaX(){
        deltaX = -deltaX;
    }
    
    /**
     * invertiert deltaY
     */
    public void invertiereDeltaY(){
        deltaY = -deltaY;
    }
    
}
