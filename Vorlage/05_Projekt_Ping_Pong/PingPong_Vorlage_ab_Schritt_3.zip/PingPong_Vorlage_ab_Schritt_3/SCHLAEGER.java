
/**
 * Write a description of class SCHLAEGER here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class SCHLAEGER extends RECHTECK{
    private int deltaX;
    private int deltaY;
    /**
     * Konstructor für Objekte der Klasse SCHLAEGER
     * @param mx  x-Koordinate des Mittelpunkts
     * @param my  y-Koordinate des Mittelpunkts
     */
    public SCHLAEGER(int mx, int my){
        super(10,100);
        setzeMittelpunkt(mx, my);
        setzeFarbe("blau");
        deltaX = 0;
        deltaY = 1;
    }
    
    /**
     * bewegt den Ball um deltaX in x-Richtung und deltaY in y-Richtung 
     */
    public void bewegen (){
        verschiebenUm(deltaX,deltaY);
    }
    
    /**
     * verringert deltaY um 1
     */
    public void verringereDeltaY(){
        deltaY = deltaY - 1;
    }
    
    /**
     * erhöht deltaY um 1
     */
    public void erhoeheDeltaY(){
        deltaY = deltaY + 1;
    }
    
    /**
     * setzt den Wert von deltaX neu
     * @param dXNeu  neuer Wert von deltaX
     */
    public void setzeDeltaX(int dXNeu){
        deltaX = dXNeu;
    }

     /**
     * setzt den Wert von deltaY neu
     * @param dYNeu  neuer Wert von deltaY
     */
    public void setzeDeltaY(int dYNeu){
        deltaY = dYNeu;
    }
}
